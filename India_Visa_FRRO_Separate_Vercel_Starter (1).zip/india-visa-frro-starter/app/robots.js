import {base} from './data';export default function robots(){return {rules:{userAgent:'*',allow:'/'},sitemap:`${base}/sitemap.xml`}}
