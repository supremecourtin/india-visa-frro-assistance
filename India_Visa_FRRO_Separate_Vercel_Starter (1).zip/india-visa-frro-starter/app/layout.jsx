import './style.css';
export const metadata={title:'India Visa & FRRO Assistance | Independent Procedural Guidance',description:'Multilingual information about Indian visa and FRRO application issues. Independent assistance, not a government website.'};
export default function Layout({children}){return <html lang="en"><body>{children}</body></html>}
