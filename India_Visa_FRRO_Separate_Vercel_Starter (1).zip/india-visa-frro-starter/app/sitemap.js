import {base,langs} from './data';
export default function sitemap(){return [...langs.map(lang=>({url:`${base}/${lang}`,lastModified:new Date(),changeFrequency:'monthly',priority:lang==='en'?1:0.9,alternates:{languages:Object.fromEntries(langs.map(l=>[l,`${base}/${l}`]))}})),{url:`${base}/privacy`,lastModified:new Date(),priority:0.2}]}
